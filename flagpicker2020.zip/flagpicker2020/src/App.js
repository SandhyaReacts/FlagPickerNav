import React, { Component } from 'react';
import {BrowserRouter} from 'react-router-dom';
import {Link } from 'react-router-dom';
import {Switch } from 'react-router-dom';
import {Route } from 'react-router-dom';

import HomeComponent from './components/Home/HomeComponent';
import FlagPicker from './container/FlagPicker';
import './_App.scss';
import './App.css';

class App extends Component {
  render() {
	  const toHome=(e)=>{
		  document.getElementById('navItemAbout').style.opacity=1;
		  document.getElementById('navItemHome').style.opacity=0.3;
		  
	  }
	  const toAbout=()=>{
		  //console.log("Welcom to about..");
		  document.getElementById('navItemAbout').style.opacity=0.3;
		  document.getElementById('navItemHome').style.opacity=1;

	  }
    return (
	<BrowserRouter>
      <div className="App">
	  <header>
	  	<nav className="navBar">
			<Link id="navItemHome" className="navItem" to="/home" onClick={toHome.bind(this)}><strong> Flagpicker </strong> </Link>
            <Link id="navItemAbout" className="navItem" to='/about' onClick={toAbout.bind(this)}><strong>AboutUs</strong></Link>
			
		</nav>
		</header>
	      <Switch>
          <Route exact path="/" component={FlagPicker}/>
          <Route exact path="/home" component={FlagPicker}/>
          <Route exact path="/About" component={HomeComponent}/>
		</Switch>
		<footer className="footer"> <nav> @sandhya </nav> </footer>
      </div>
	</BrowserRouter>
    );
  }
}

export default App;
