import React from 'react';
import '../../_App.scss';
//import  '../../App.css';
 /*Loads the 
	heading*/
const HomeComponent=()=>
{
    return (
            <div className="">
             <strong>
				<p className="appName"> Hello I'm a Flag Picker App</p>
				<p className="appDesc colorgray"> <span> I help you learn flag around the world in </span>
				<span className="underlineText">Just 3 steps </span>
				<span> Now,click on flagpicker above to get started!!! </span></p>
			</strong>
			</div>
			);
};
 
export default HomeComponent;
