import React from 'react';
import '../../_App.scss';
//import  '../../App.css';
import DisplayFlagSubComponent from './DisplayFlagSubComponent';
 
const DisplayFlagContainer=(props)=>
{
    
	if(props.displayFlags)
	{
			return(
				<div className="flagClass" >
				<strong> <p className="largeFont"> Selected Flags:</p> </strong>
				<br/>
				<div className="parentFlag">
				<div className="flagContainer flex-container-flag">
					<DisplayFlagSubComponent country={props.allCodes} countryCode={props.countryCode}/>
				</div>
				</div>
				<br/>
				<button className="clearFlags" onClick={props.onClick}> Clear Flags </button>
			</div>);

	}
	else
		return null;
	
};
 
export default DisplayFlagContainer;

