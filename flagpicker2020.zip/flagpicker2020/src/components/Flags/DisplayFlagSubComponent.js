import React from 'react';
import '../../_App.scss';
//import  '../../App.css';
const DisplayFlagSubComponent=(props)=>
{
	 const displayHoverText =(e)=> {
		 for( let i=0;i<document.getElementsByClassName('toolTip').length;i++)
		 {
			document.getElementById(e.target.id).style.opacity=0.3;		
			 if (document.getElementsByClassName('toolTip')[i].children[0].className==e.target.id)
			 document.getElementsByClassName('toolTip')[i].style.display='block';
		 }
	 }
	 const hideHoverText=(e)=>{
		 document.getElementById(e.target.id).style.opacity=1;
		 for( let i=0;i<document.getElementsByClassName('toolTip').length;i++)
			 document.getElementsByClassName('toolTip')[i].style.display='none';
	 }

		return(
		props.countryCode.map((item) => {
				
				return (
						<div>
						<img className="flagImg" key ={item.flagCode} src={`http://www.countryflags.io/${item.flagCode}/shiny/64.png`} 
							id={`FL-${item.country}`} alt="Failed to load..." onMouseOver={displayHoverText.bind(this)} onMouseOut={hideHoverText.bind(this)}
							 />
						<div className="toolTip">
						<nav id="toolTipNav" className={`FL-${item.country}`}> {item.country} </nav>
						</div>
						</div>
						);
			})

		);
	
	
};
export default DisplayFlagSubComponent;
 

				
