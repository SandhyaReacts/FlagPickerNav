import React from 'react';
import '../../_App.scss';
//import  '../../App.css';
import fragment from 'react';
const LoadCountriesList=(props)=>
{
	
		return(
		props.countriesArr.map((item) => {
			return (
				 <div key ={`div${item}` } className="countriesList">
						<input key= {item} value= {item} className="checkbox" type="checkbox" name="" id={`check${item}`} onChange={props.onChange}/>
						<a key ={`anchor${item}`} className="" id={item}>{item}</a>
                 </div>
			);
		})

		);
};
 
export default LoadCountriesList;
 

				
