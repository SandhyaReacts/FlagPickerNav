import React, { Component } from 'react';

import FlagPicker from './container/FlagPicker';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
       <FlagPicker />
      </div>
    );
  }
}

export default App;
