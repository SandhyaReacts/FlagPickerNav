import React from 'react';
import  '../../App.css';
import DisplayFlagSubComponent from './DisplayFlagSubComponent';
 
const DisplayFlagContainer=(props)=>
{
    
	if(props.displayFlags)
	{
			return(
				<div>
				<strong> <p className="largeFont"> Selected Flags:</p> </strong>
				<br/>
				<div className="parentFlag">
				<div className="flagContainer">
					<DisplayFlagSubComponent countryCode={props.countryCode}/>
				</div>
				</div>
				<br/>
				<button className="clearFlags" onClick={props.onClick}> Clear Flags </button>
			</div>);

	}
	else
		return null;
	
};
 
export default DisplayFlagContainer;

