import React from 'react';
import  '../../App.css';
const DisplayFlagSubComponent=(props)=>
{
	
	
		return(
		props.countryCode.map((item) => {
				return (
						
						<img key ={item} src={`http://www.countryflags.io/${item}/shiny/64.png`} 
							 alt="Failed to load..."
							 />
						
						);
			})

		);
	
	
};
 
export default DisplayFlagSubComponent;
 

				
